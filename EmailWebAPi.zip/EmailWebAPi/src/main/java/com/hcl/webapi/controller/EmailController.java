package com.hcl.webapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hcl.webapi.model.EmailRequest;
import com.hcl.webapi.service.EmailService;

@RestController
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailController {

	@GetMapping("mapurl")
	public ModelAndView edureka() {
		return new ModelAndView("index");
	}
	
	@RequestMapping(value = "/sendMail", method = RequestMethod.POST)
	public ResponseEntity<?> sendEmail(EmailRequest request){
		System.err.println("EmailController.sendEmail() request "+request);
		//System.out.println(email+" \n"+ subject+"\n"+msg);
		EmailService.sendEmail(request.getMessage(), request.getSubject(), request.getTo(), "sundramkdubey@gmail.com");
		return ResponseEntity.ok("Done..");
	}
}
