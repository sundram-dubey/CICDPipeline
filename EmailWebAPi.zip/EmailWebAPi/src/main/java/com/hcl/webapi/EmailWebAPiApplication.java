package com.hcl.webapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailWebAPiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailWebAPiApplication.class, args);
		/*
		 * String message = "Hello, Gya??"; String subject = "JavaArena : EmailApi";
		 * String to = "stushivam@gmail.com"; String from = "sundramkdubey@gmail.com";
		 */

	}
}
